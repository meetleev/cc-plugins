const gulp = require('gulp');
const uglify = require('gulp-uglify-es').default; // 压缩文件
const concat = require('gulp-concat'); // 合并文件
const babel = require("gulp-babel");
const wrap = require('gulp-wrap');

const files = [
    'lib/component/BaseWidget.js',
    'lib/utils/bind.js',
    'lib/utils/Log.js',
    'lib/utils/wx-sysfunc.js',
    'lib/utils/SysFunc.js',
    'lib/utils/SysFuncCommon.js',
    'lib/utils/NotificationCenter.js',
    // 'lib/utils/CLLocationFactory.js',
    'lib/utils/AudioMgr.js',
];

gulp.task('scripts', function () {
    return gulp.src(files)
        .pipe(concat('js-cocos-ccx.js'))
        .pipe(babel())
        .pipe(wrap({src: 'lib/template.txt'}, {variable: 'data'}))
        .pipe(uglify({
            mangle: {
                eval: true, toplevel: false, properties: {regex: /^_/}
            },
            compress: {
                unused: true,
                keep_fargs: false,
                unsafe: true
            },
            // keep_classnames:true,
            // output: {
            //     beautify: true,
            // }

        }))
        .pipe(gulp.dest('bin/'))
});

gulp.task('build', ['scripts']);
gulp.task('default', ['build']);
